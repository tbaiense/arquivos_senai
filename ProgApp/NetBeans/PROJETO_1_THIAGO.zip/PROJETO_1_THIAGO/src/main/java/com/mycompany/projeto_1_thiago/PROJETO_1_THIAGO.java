/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_1_thiago;

/**
 *
 * @author t.baiense
 */
public class PROJETO_1_THIAGO {

    public static void main(String[] args) {
        System.out.println("Hello world.");
    }
}
