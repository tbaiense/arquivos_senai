/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_5_thiago;
import java.util.Scanner;
/**
 *
 * @author t.baiense
 */
public class PROJETO_5_THIAGO {

    public static void main(String[] args) {
        int n;
        Scanner ler = new Scanner(System.in);
        System.out.println("Digite um número: ");
        n = ler.nextInt();
        System.out.println(n);
    }
}
