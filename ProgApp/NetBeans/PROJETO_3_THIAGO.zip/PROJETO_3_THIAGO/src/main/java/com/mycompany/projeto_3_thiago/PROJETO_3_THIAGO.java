/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_3_thiago;

/**
 *
 * @author t.baiense
 */
public class PROJETO_3_THIAGO {

    public static void main(String[] args) {
        int x=10, y=3;
        System.out.println(x + (y / y)); //11
        System.out.println(x / (y - y / y)); //5
        System.out.println(x * y - (y * y - y)); //24
        System.out.println(x - y + (y / y)); //8
    }
}
