/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_2_thiago;

/**
 *
 * @author t.baiense
 */
public class PROJETO_2_THIAGO {

    public static void main(String[] args) {
        int x=10, y=3;
        System.out.println(x +3); //13
        System.out.println(x - 3); //7
        System.out.println(x * y); //30
        System.out.println(x++); //11
    }
}
