/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_4_thiago;

/**
 *
 * @author t.baiense
 */
public class PROJETO_4_THIAGO {

    public static void main(String[] args) {
        int x=10, y=3;
        System.out.println(x == x); //TRUE
        System.out.println(x == y); //FALSE
        System.out.println(x > y); //TRUE
        System.out.println(y > x); //FALSE
    }
}
